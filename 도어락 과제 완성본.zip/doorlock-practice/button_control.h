#ifndef	BUTTON_CONTROL_H
#define BUTTON_CONTROL_H

#include "mbed.h"

#define FIRST_BTN_PIN   PA_14
#define SECOND_BTN_PIN	PB_7
#define THIRD_BTN_PIN		PC_4

DigitalIn btn1(FIRST_BTN_PIN);
DigitalIn btn2(SECOND_BTN_PIN); 
DigitalIn btn3(THIRD_BTN_PIN);

typedef enum {
	NO_EDGE=0, RISING_EDGE, FALLING_EDGE
} edge_t;

#define BUTTON1() (detectBtn1Edge() == FALLING_EDGE)

edge_t detectBtn1Edge() {
	static int prevState = 1;
	edge_t edge = NO_EDGE;
	
	int currState = btn1;
	if (currState != prevState) {
		wait_ms(50);		// debouncing delay  50ms
		currState = btn1;
		if (currState != prevState) {
			if (currState == 1) edge = RISING_EDGE;
			else edge = FALLING_EDGE;
			prevState = currState;
		}
	}
	
	return edge;
}

#define BUTTON2() (detectBtn2Edge() == FALLING_EDGE)

edge_t detectBtn2Edge() {
	static int prevState = 1;
	edge_t edge = NO_EDGE;
	
	int currState = btn2;
	if (currState != prevState) {
		wait_ms(50);		// debouncing delay  50ms
		currState = btn2;
		if (currState != prevState) {
			if (currState == 1) edge = RISING_EDGE;
			else edge = FALLING_EDGE;
			prevState = currState;
		}
	}
	
	return edge;
}

#define BUTTON3() (detectBtn3Edge() == FALLING_EDGE)

edge_t detectBtn3Edge() {
	static int prevState = 1;
	edge_t edge = NO_EDGE;
	
	int currState = btn3;
	if (currState != prevState) {
		wait_ms(50);		// debouncing delay  50ms
		currState = btn3;
		if (currState != prevState) {
			if (currState == 1) edge = RISING_EDGE;
			else edge = FALLING_EDGE;
			prevState = currState;
		}
	}
	
	return edge;
}

#endif
