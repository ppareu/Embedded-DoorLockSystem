#ifndef	LED_CONTROL_H
#define LED_CONTROL_H

#include "mbed.h"

#define GREEN_LED_PIN	PA_13
#define YELLOW_LED_PIN PB_10
#define RED_LED_PIN	PA_4

#define JOYSTICK_X_PIN   PC_2
#define JOYSTICK_Y_PIN   PC_3

DigitalOut greenLed(GREEN_LED_PIN);
DigitalOut yellowLed(YELLOW_LED_PIN);
DigitalOut redLed(RED_LED_PIN);

Ticker jsTicker;
Ticker doorTicker;
Ticker yellowLedTicker;


AnalogIn xAxis(JOYSTICK_X_PIN);
AnalogIn yAxis(JOYSTICK_Y_PIN);

int x, y;

#define NETURAL_VALUE 73

void yellowTiker() {
	yellowLed = 0;
}
#endif