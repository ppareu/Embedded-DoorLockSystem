#include "motordriver.h"

Motor::Motor(PinName pwm, PinName dir):
	_pwm(pwm), _dir(dir)
{
	_pwm.period(0.001);		// period = 1msec => freq. = 1000Hz
	_pwm = 0;							// pulse width = 0;
	
	_dir = M_FORWARD;
	_speed = 0;
}

void Motor::forward(double speed) {
	if (_dir == M_BACKWARD && _speed > 0) {
		_pwm = 0;
		wait(0.1);
	}
	
	_dir = M_FORWARD;
	_speed = fabs(speed);
	_pwm = _speed;
}

void Motor::backward(double speed) {
	if (_dir == M_FORWARD && _speed > 0) {
		_pwm = 0;
		wait(0.1);
	}
	_dir = M_BACKWARD;
	_speed = fabs(speed);
	_pwm = _speed;
}

void Motor::stop() {
	_pwm = 0;
	_speed = 0;
}

void Motor::setSpeed(double speed) {
	_speed = fabs(speed);
	_pwm = _speed;
}

void Motor::incSpeed(double step) {
	_speed += step;
	if (_speed > 1.0)  _speed = 1.0;
	_pwm = _speed;
}

void Motor::decSpeed(double step) {
	_speed -= step;
	if (_speed < 0)	_speed = 0;
	_pwm = _speed;
}

void Motor::setDir() {
	if (_dir == 0) _dir=1;
	else _dir=0;
}
