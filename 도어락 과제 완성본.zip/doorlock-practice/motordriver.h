#ifndef	_MOTORDRIVER_H_
#define	_MOTORDRIVER_H_

#include "mbed.h"

#define	M_FORWARD			0
#define	M_BACKWARD		1

class Motor {
	public:
		Motor(PinName pwm, PinName dir);
		void forward(double speed);
		void backward(double speed);
		void stop();
		void setSpeed(double speed);
		void incSpeed(double step);
		void decSpeed(double step);
		void setDir();
	private:
		PwmOut _pwm;
		DigitalOut _dir;
		double _speed;
};

#endif
