#include "mbed.h"
#include "Adafruit_SSD1306.h"
#include "DHT22.h"
#include "motordriver.h"
#include "button_control.h"
#include "buzzer_sound.h"
#include "led_control.h"

#define DHT22_SDA_PIN    PB_2
#define MOTOR_A_FWM_PIN  PA_7
#define MOTOR_A_DIR_PIN  PC_8

I2C i2cMaster(I2C_SDA, I2C_SCL);    // D14, D15
Adafruit_SSD1306_I2c Oled(i2cMaster, D13, 0x78, 64, 128);
DHT22 dht22(DHT22_SDA_PIN);
Motor motor(MOTOR_A_FWM_PIN, MOTOR_A_DIR_PIN);

double speed     = 0.4;
int pwd[4]       = {1, 2, 3, 4};
int input_pwd[4] = {0, 0, 0, 0};
int inputIndex   = 0;
bool door_State;
Timer autoLockTimer;



void getTempHumidity() {
  if (dht22.sample()) {
    Oled.setTextCursor(0, 0);
    Oled.printf("Temp: %4.1f C\t\t\n Humidity: %4.1f %% \n", 
    dht22.getTemperature() / 10.0, dht22.getHumidity() / 10.0, Oled.width(), Oled.height());
		Oled.printf("Door : %s\r\n",door_State?"open ":"close");
    Oled.display();
    wait(1.0);
  }
}

void readJoystick() {
   x = xAxis * 100;
   y = yAxis * 100;

   x = NETURAL_VALUE - x;
   if (abs(x) <= 3)  x = 0;

   y = NETURAL_VALUE - y;
   if (abs(y) <= 3)  y = 0;
   
   if(x>0 && y==0){
      
      if(inputIndex == 0){
				CheckMelo();
        inputIndex = 0;
      }
      else{
				CheckMelo();
        inputIndex--;
      }
   }
   else if(x<0 && y==0){
      if(inputIndex == 3){
				CheckMelo();
				inputIndex = 3;
      }
      else{
				CheckMelo();
        inputIndex++;
      }
   }
   else if(x==0 && y>0){
      if(input_pwd[inputIndex] == 9){
				CheckMelo();
				input_pwd[inputIndex] = 0;
      }
      else{
				CheckMelo();
        input_pwd[inputIndex]++;
      }
   }
   else if(x==0 && y<0){
      if(input_pwd[inputIndex] == 0){
				CheckMelo();
				input_pwd[inputIndex] = 9;
      }
      else{
				CheckMelo();
        input_pwd[inputIndex]--;
      }
   }
}

void playOpenMelody() {
   for (int i = 0; i < sizeof(openmelody) / sizeof(openmelody[0]); i++) {
      playTone(openmelody[i]);
      wait_ms(300);
   }
   buzzer = 0;
}

void playCloseMelody() {
   for (int i = 0; i < sizeof(closemelody) / sizeof(closemelody[0]); i++) {
      playTone(closemelody[i]);
      wait_ms(300);
   }
   buzzer = 0;
}

void button_ISR() {
    if (memcmp(input_pwd, pwd, sizeof(pwd)) == 0) {
        playOpenMelody();
        door_State = true;
        //presState();
				greenLed = 1;
        motor.forward(speed);
				redLed = 0;
        autoLockTimer.start();
				wait(3.0);
				motor.stop();
				greenLed = 0;
				Oled.clearDisplay();
				getTempHumidity();
    } else {
        playCloseMelody();
				redLed = 1;
				greenLed = 0;
				wait(1.0);
				redLed = 0;
				greenLed = 0;
    }
    memset(input_pwd, 0, sizeof(input_pwd));  // Clear the input password after checking
}

void autoLock() {
    if (door_State == true && autoLockTimer.read() >= 30) {  // If door is open and timer has reached 30 secondsmotor.backward(0.1);
        door_State = false;
        playCloseMelody();
        //presState();
				motor.backward(speed);
        autoLockTimer.stop();
        autoLockTimer.reset();
				redLed = 1;
				greenLed = 0;
				wait(3.0);
				motor.stop();
				redLed = 0;
				Oled.clearDisplay();
				getTempHumidity();
    }
}

void setup() {
  greenLed=0;
	motor.stop();
	i2cMaster.frequency(400000);
	door_State = false;
	Oled.clearDisplay();
	jsTicker.attach(&readJoystick, 0.2);
	buzzer.period_us(C_NOTE_HALF_PERIOD * 2);
  buzzer = 0;
}

int main() {
	bool inverted = false;
	int textSize = 1;
	float temp, humidity;

  setup();

	wait(5.0);

	Oled.setTextSize(textSize);
	getTempHumidity();
	Oled.display();

  while(1) {

		Oled.setTextSize(textSize);

		Oled.setTextCursor(29, 29);

		for(int i=0;i<4;i++){
			 Oled.printf("%d",input_pwd[i]);
		}

		if(BUTTON3()){
			button_ISR();
		}
		
		autoLock();
		Oled.display();

		wait(1.0);
  }
	

}